<?php

//Ваше имя пользователя через @
$NameWorkera = "@iam_alah";

//Телеграм ид воркера ( с @getmyid_bot)
$idworkera = "1068775099";

//Создайте бота тут @BotFather и впишите токен бота 
$bottoken = "1126581451:AAEKnWCNokgyoPeUeW6IIN6FVX7WVyhUCWg";

//Название вашего сайта
$name = "Example";

//Название вашего файла
$filename = "Setup.exe";

?>